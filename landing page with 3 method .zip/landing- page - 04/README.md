# landing  page 


landing page project is page  contain 4 section and nav menu and contain 3 file (index.html ,app.js,styles.css)





# contents of landing page 

page contain 4 section  and 4 navigation menu 

# installation 

  unzip file you can run file index.html by google chorm browser or fixfox or inernet explorer 
  
# Development

project is open source 

#Designer 

design by hossam salah eid 




  



